<?php
echo '<div align="center">';
echo '<table width="200">
<tr><td colspan="2" bgcolor="#CCCCCC"><b>NOMBRE MODULO</b></td><tr>';

// --------------check permisos -----------------

$idusuario = $_COOKIE["lnxuserid"];

//buscamos los grupos a los que pertenece el usuario
$sqlpermisosefe = $mysqli->query("select * from lnx_usersgroup  where iduser = '".$idusuario."' order by idgroup");

while($dbgrupos = mysqli_fetch_array($sqlpermisosefe))
{
	if ($idgrupos == '')
	{
		$idgrupos = "idgrupo = '".$dbgrupos["idgroup"]."' ";
	}else
	{
		$idgrupos = $idgrupos." or idgrupo = '".$dbgrupos["idgroup"]."' ";
	}
}
//ditinc idpermiso (asi eviatmos duplicados de permisos entre grupos)
//en la consulta especificamos el idpermiso
//si es admin podrá eliminar el ticket sino, no

$sqlpermisosefe = $mysqli->query("SELECT COUNT(DISTINCT idpermiso) as npermisos FROM lnx_permisosgrupos WHERE iduser = '".$idusuario."' or (".$idgrupos.") and idpermiso = '2000'");


$rowperm = mysqli_fetch_assoc($sqlpermisosefe);
$dbrspermisos = $rowperm['npermisos'];

if ($dbrspermisos > 0)
{

//FIN CHECK PERMISOS

//SI ES OK

	if ($_GET["section"] == 'tickets' || $_GET["section"] == 'seguimiento' || $_GET["section"] == 'docs')
		{
			$selecionado = 'class="menuactivo"';
			$menuestilo = 'class="selmenulatactivo"';
			$menuestilotext = 'class="selmenulattextactivo"';
		}else
		{
			$selecionado = 'bgcolor="#CCCCCC"';
			$menuestilo = 'class="selmenulat"';
			$menuestilotext = 'class="selmenulattext"';
		}
	echo '<tr '.$menuestilo.'><td width="5" '.$selecionado.'></td><td><A '.$menuestilotext.' HREF="index.php?module=lnxit&section=tickets&subsection=list">Gestion Tickets</A></td><tr>';

	if ($_GET["section"] == 'buscaseg')
		{
			$selecionado = 'class="menuactivo"';
			$menuestilo = 'class="selmenulatactivo"';
			$menuestilotext = 'class="selmenulattextactivo"';
		}else
		{
			$selecionado = 'bgcolor="#CCCCCC"';
			$menuestilo = 'class="selmenulat"';
			$menuestilotext = 'class="selmenulattext"';
		}
	echo '<tr '.$menuestilo.'><td width="5" '.$selecionado.'></td><td><A '.$menuestilotext.' HREF="index.php?module=lnxit&section=buscaseg">Busqueda en seguimientos</A></td><tr>';
	}
//FIN SI ES OK

else
{
echo '<p>NO TIENE PRIVILEGIOS PARA ESTE MODULO</P>';   
}

echo '</table>';
echo '</div>';

?>