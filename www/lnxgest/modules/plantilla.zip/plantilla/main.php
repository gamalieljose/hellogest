<?php
require("core/cfpc.php");
echo '<p>MODULO PRODUCTS</p>';


// --------------check permisos -----------------

$idusuario = $_COOKIE["lnxuserid"];

//buscamos los grupos a los que pertenece el usuario
$sqlpermisosefe = $mysqli->query("select * from lnx_usersgroup  where iduser = '".$idusuario."' order by idgroup");

while($dbgrupos = mysqli_fetch_array($sqlpermisosefe))
{
   if ($idgrupos == '')
   {
      $idgrupos = "idgrupo = '".$dbgrupos["idgroup"]."' ";
   }else
   {
      $idgrupos = $idgrupos." or idgrupo = '".$dbgrupos["idgroup"]."' ";
   }
}
//ditinc idpermiso (asi evitAmos REGISTROS duplicados de permisos entre grupos)
//en la consulta especificamos el idpermiso
//si es admin podrá eliminar el ticket sino, no

//En idpermiso = '2000' especificar el ID permiso o IDpermisos que han de tener acceso
$sqlpermisosefe = $mysqli->query("SELECT COUNT(DISTINCT idpermiso) as npermisos FROM lnx_permisosgrupos WHERE iduser = '".$idusuario."' or (".$idgrupos.") and idpermiso = '2000'");


$rowperm = mysqli_fetch_assoc($sqlpermisosefe);
$dbrspermisos = $rowperm['npermisos'];

if ($dbrspermisos > 0)
{
	
	// AQUI EL CODIGGO DE SI ACCESSO = OK
	
}
else
{
	//CODIGO ACCESO ES KO
echo '<p>NO TIENE PRIVILEGIOS PARA ESTE MODULO</P>';   
}


?>