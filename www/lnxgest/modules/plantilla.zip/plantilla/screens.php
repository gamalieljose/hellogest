<?php
if ($_GET["section"] == '') 
{
	$numscreen = "100";
	$displaytitle = "titulo";
	
}

?>